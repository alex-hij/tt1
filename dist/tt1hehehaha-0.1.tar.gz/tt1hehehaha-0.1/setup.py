# setup.py
from setuptools import setup, find_packages

setup(
    name='tt1hehehaha',
    version='0.1',
    packages=find_packages(),
    author='alex uv',
    description='A simple hello world package',
    python_requires='>=3.6',
)
